module.exports = (sequelize, DataTypes) => {
    return sequelize.define('Login_db', {
        id: {
            type: DataTypes.STRING,
            allowNull: false,
            primaryKey: true,
            autoIncrement: true
        },
        user_id: {
            type: DataTypes.STRING,
            allowNull: false
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false
        },
        user_group: {
            type: DataTypes.STRING,
            allowNull: false
        },
        params: {
            type: DataTypes.STRING,
            allowNull: false
        },
        ban: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    });
}