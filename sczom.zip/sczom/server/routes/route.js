const express = require('express');
const router = express.Router();
const morgan = require('morgan');
const path = require('path');

router.use(morgan('dev'));
router.use(express.static(path.join(__dirname,'public')));

router.use(express.json());
router.use(express.urlencoded({ extended: true })); 

router.use('/', function (req, res, next) {
    console.log('Request URL:', req.originalUrl)
    next()
}, function (req, res, next) {
    console.log('Request Type:', req.method)
    next()
});


router.use((req, res, next) => {
    next()
});

router.get('/', (req, res) => {
    res.render('index.html')
});

module.exports = router;