const express = require('express');
const path = require('path');
const logger = require('morgan');
const port = process.env.PORT || 3000;
const app = express();

app.use(logger('dev'));

app.set('views', __dirname + '/');
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

app.use(express.json());
app.use(express.urlencoded({ extended: true })); 
app.use('/', express.static('../public/views'));
app.use('/', express.static('../public/css'));
app.use('/', express.static('../public/client'));

app.use('/', function (req, res, next) {
    console.log('Request URL:', req.originalUrl)
    next()
}, function (req, res, next) {
    console.log('Request Type:', req.method)
    next()
});

app.post('/', (req, res, next) => {
    const conn = req.body.connect;
    console.log(conn);
    if(conn == 1) {
        console.log('main server connection success');
    }
});

app.listen(port, function() {
    console.log(`PORT : http://localhost:${port}`);
}); 
